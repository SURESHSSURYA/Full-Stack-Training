package com.emp;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class AssociateProjectTOEmployeeManyTOMany {

	EntityManagerFactory emf = null;
	EntityManager entityManager = null;
	EntityTransaction transaction = null;

	void getProjects(int empId) {
		try {
			emf = Persistence.createEntityManagerFactory("corebanking");
			entityManager = emf.createEntityManager();

			transaction = entityManager.getTransaction();

			// start transaction
			transaction.begin();

			Employee employee = entityManager.getReference(Employee.class, empId);

			List<Project> projlist = employee.getProjects();
			System.out.println(projlist.size());

			for (Project p : projlist) {
				System.out.println(p.getProjectId());
				System.out.println(p.getDescription());
				System.out.println(p.getProjCode());
			}

			System.out.println("Project associated to employee successfull....");

		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
		} finally {
			if (transaction != null) {
				transaction.commit();
			}
			if (entityManager != null) {
				entityManager.close();
			}
			if (emf != null) {
				emf.close();
			}
		}

	}

	void getEmployees(int projectId) {
		try {
			emf = Persistence.createEntityManagerFactory("corebanking");
			entityManager = emf.createEntityManager();

			transaction = entityManager.getTransaction();

			// start transaction
			transaction.begin();

			Project project = entityManager.getReference(Project.class, projectId);

			Set<Employee> emplist = project.getEmployees();
			System.out.println(emplist.size());

			for (Employee e : emplist) {
				System.out.println("Employee id....:" + e.getEid());
				System.out.println(e.getContactNo());
				System.out.println(e.getAge());
			}

			System.out.println("Project associated to employee successfull....");

		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
		} finally {
			if (transaction != null) {
				transaction.commit();
			}
			if (entityManager != null) {
				entityManager.close();
			}
			if (emf != null) {
				emf.close();
			}
		}

	}

	void retriveRecBasedOnProjects(int projectId) {
		try {
			emf = Persistence.createEntityManagerFactory("corebanking");
			entityManager = emf.createEntityManager();

			transaction = entityManager.getTransaction();

			// start transaction
			transaction.begin();

			Query q = entityManager.createQuery("from Project where projectId=" + projectId);
			// SELECT * FROM movie WHERE title LIKE '%in%';

			List<Project> projectList = q.getResultList();

			System.out.println(projectList.size());

			for (Project p : projectList) {
				Set<Employee> employeeList = p.getEmployees();

				for (Employee emp : employeeList) {
					System.out.println("Employee id....:" + emp.getEid());
					System.out.println(emp.getContactNo());
					System.out.println(emp.getAge());
				}
			}

			System.out.println("Project associated to employee successfull....");

		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
		} finally {
			if (transaction != null) {
				transaction.commit();
			}
			if (entityManager != null) {
				entityManager.close();
			}
			if (emf != null) {
				emf.close();
			}
		}

	}

	void associateProjectToEmployee() {
		try {
			emf = Persistence.createEntityManagerFactory("corebanking");
			entityManager = emf.createEntityManager();

			transaction = entityManager.getTransaction();

			// start transaction
			transaction.begin();

			Employee employee = entityManager.getReference(Employee.class, 7);
			Project project = entityManager.getReference(Project.class, 1);

			List<Project> projlist = employee.getProjects();
			projlist.add(project);

			System.out.println("Project associated to employee successfull....");

		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
		} finally {
			if (transaction != null) {
				transaction.commit();
			}
			if (entityManager != null) {
				entityManager.close();
			}
			if (emf != null) {
				emf.close();
			}
		}

	}

	public static void main(String[] args) {
		AssociateProjectTOEmployeeManyTOMany associateProjectTOEmployeeManyTOMany = new AssociateProjectTOEmployeeManyTOMany();
		// associateProjectTOEmployeeManyTOMany.associateProjectToEmployee();
		associateProjectTOEmployeeManyTOMany.getProjects(3);
		// associateProjectTOEmployeeManyTOMany.getEmployees(7);
		associateProjectTOEmployeeManyTOMany.retriveRecBasedOnProjects(1);
	}

}
